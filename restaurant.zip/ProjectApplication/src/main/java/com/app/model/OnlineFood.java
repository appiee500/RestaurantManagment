package com.app.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OnlineFood {
@Id
private int ofId;
private String ofName;
private int ofPrice;
public OnlineFood(int ofId, String ofName, int ofPrice) {
	super();
	this.ofId = ofId;
	this.ofName = ofName;
	this.ofPrice = ofPrice;
}
public int getOfId() {
	return ofId;
}
public void setOfId(int ofId) {
	this.ofId = ofId;
}
public String getOfName() {
	return ofName;
}
public void setOfName(String ofName) {
	this.ofName = ofName;
}
public int getOfPrice() {
	return ofPrice;
}
public void setOfPrice(int ofPrice) {
	this.ofPrice = ofPrice;
}
@Override
public String toString() {
	return "OnlineFood [ofId=" + ofId + ", ofName=" + ofName + ", ofPrice=" + ofPrice + "]";
}
public OnlineFood() {
	super();
	// TODO Auto-generated constructor stub
}


}
