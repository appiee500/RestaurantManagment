package com.app.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OnlineBeverages {
@Id
private int obId;
private String obName;
private int obPrice;

public OnlineBeverages() {
	super();
	// TODO Auto-generated constructor stub
}
public OnlineBeverages(int obId, String obName, int obPrice) {
	super();
	this.obId = obId;
	this.obName = obName;
	this.obPrice = obPrice;
}
public int getObId() {
	return obId;
}
public void setObId(int obId) {
	this.obId = obId;
}
public String getObName() {
	return obName;
}
public void setObName(String obName) {
	this.obName = obName;
}
public int getObPrice() {
	return obPrice;
}
public void setObPrice(int obPrice) {
	this.obPrice = obPrice;
}
@Override
public String toString() {
	return "OnlineBeverages [obId=" + obId + ", obName=" + obName + ", obPrice=" + obPrice + "]";
}

}
