package com.app.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class FoodMenu {
	public FoodMenu() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Id
	private int foodId;
	private String foodName;
	private int foodPrice;
	public FoodMenu(int foodId, String foodName, int foodPrice) {
		super();
		this.foodId = foodId;
		this.foodName = foodName;
		this.foodPrice = foodPrice;
	}
	public int getFoodId() {
		return foodId;
	}
	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public int getFoodPrice() {
		return foodPrice;
	}
	public void setFoodPrice(int foodPrice) {
		this.foodPrice = foodPrice;
	}
	@Override
	public String toString() {
		return "FoodMenu [foodId=" + foodId + ", foodName=" + foodName + ", foodPrice=" + foodPrice + "]";
	}
	
	
	
}
