package com.app.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class CustomerOrder {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int orderId;
	private String CustomerName;
	private String orderName;
	private int orderPrice;
	private int count;
	private double bill;
	private double totalbill;
	public CustomerOrder() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getOrderName() {
		return orderName;
	}
	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}
	public int getOrderPrice() {
		return orderPrice;
	}
	public void setOrderPrice(int orderPrice) {
		this.orderPrice = orderPrice;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public double getBill() {
		return bill;
	}
	public void setBill(double bill) {
		this.bill = bill;
	}
	public double getTotalbill() {
		return totalbill;
	}
	public void setTotalbill(double totalbill) {
		this.totalbill = totalbill;
	}
	
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public CustomerOrder(int orderId, String orderName, int orderPrice, int count, double bill, double totalbill) {
		super();
		this.orderId = orderId;
		this.orderName = orderName;
		this.orderPrice = orderPrice;
		this.count = count;
		this.bill = bill;
		this.totalbill = totalbill;
	}
	@Override
	public String toString() {
		return "CustomerOrder [orderId=" + orderId + ", CustomerName=" + CustomerName + ", orderName=" + orderName
				+ ", orderPrice=" + orderPrice + ", count=" + count + ", bill=" + bill + ", totalbill=" + totalbill
				+ "]";
	}
	
	
	
	

}
