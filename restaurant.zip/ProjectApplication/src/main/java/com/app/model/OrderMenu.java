package com.app.model;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class OrderMenu {
	@Id
	private int orderId;
	private String orderName;
	private int orderPrice;
	private int count;
	public OrderMenu() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderMenu(int orderId, String orderName, int orderPrice, int count) {
		super();
		this.orderId = orderId;
		this.orderName = orderName;
		this.orderPrice = orderPrice;
		this.count = count;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getOrderName() {
		return orderName;
	}
	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}
	public int getOrderPrice() {
		return orderPrice;
	}
	public void setOrderPrice(int orderPrice) {
		this.orderPrice = orderPrice;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "OrderMenu [orderId=" + orderId + ", orderName=" + orderName + ", orderPrice=" + orderPrice + ", count="
				+ count + "]";
	}
	
}
