package com.app.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BeveragesMenu {
@Id
private int bId;
private String bName;
private int bPrice;



public BeveragesMenu() {
	super();
	// TODO Auto-generated constructor stub
}
public BeveragesMenu(int bId, String bName, int bPrice) {
	super();
	this.bId = bId;
	this.bName = bName;
	this.bPrice = bPrice;
}
public int getbId() {
	return bId;
}
public void setbId(int bId) {
	this.bId = bId;
}
public String getbName() {
	return bName;
}
public void setbName(String bName) {
	this.bName = bName;
}
public int getbPrice() {
	return bPrice;
}
public void setbPrice(int bPrice) {
	this.bPrice = bPrice;
}
@Override
public String toString() {
	return "BeveragesMenu [bId=" + bId + ", bName=" + bName + ", bPrice=" + bPrice + "]";
}


}
