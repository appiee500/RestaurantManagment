package com.app.dao;

import java.util.List;

import com.app.model.BeveragesMenu;

public interface BeveragesMenuDao {
	int addOfflineBeverages();
	List<BeveragesMenu> getMenu();

}
