package com.app.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.app.dao.OrderDao;
import com.app.model.BeveragesMenu;
import com.app.model.CustomerOrder;
import com.app.model.OrderMenu;
import com.app.service.BeveragesMenuService;
import com.app.service.OrderMenuService;
import com.app.util.HibernateUtil;

public class OrderDaoImpl implements OrderDao {

	@Override
	public int addOrder() {

		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession();
			tx = session.beginTransaction();
		OrderMenu om=new OrderMenuService().addOrder();
		session.save(om);
		tx.commit();

		return 1;
		
	}catch (Exception e) {
		e.printStackTrace();
		return 0;
	} finally {
		if (session != null) {
			session.close();
		}
	}
	}
	

	public List<CustomerOrder> placeorder(List<Map<String,Integer>>orders,String Menu) {
		CustomerOrder customerorder=new CustomerOrder();
		OrderMenu orderMenu=new OrderMenu();
		
		List<CustomerOrder>list=new ArrayList();
	
		Session session =HibernateUtil.getSession();
		Transaction tx =  session.beginTransaction();
		for(Map<String,Integer> or:orders) {
		for(Entry<String,Integer>s:or.entrySet()) {
		
		tx.commit();
		}
		}
		return list;
	}



	@Override
	public List<OrderMenu> getMenu(List<Map<String, Integer>> orders, String user) {
		// TODO Auto-generated method stub
		return null;
	}
	}