package com.app.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.app.dao.BeveragesMenuDao;
import com.app.model.BeveragesMenu;
import com.app.model.FoodMenu;
import com.app.service.BeveragesMenuService;
import com.app.service.FoodMenuService;
import com.app.util.HibernateUtil;

public class BeveragesMenuImpl implements BeveragesMenuDao{

	@Override
	public int addOfflineBeverages() {


		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession();
			tx = session.beginTransaction();
		BeveragesMenu obv= new BeveragesMenuService().addOfflineBeverages();
		session.save(obv);
		tx.commit();

		return 1;
		
	}catch (Exception e) {
		e.printStackTrace();
		return 0;
	} finally {
		if (session != null) {
			session.close();
		}
	}
	}

	

	@Override
	public List<BeveragesMenu> getMenu() {


		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession();
			tx = session.beginTransaction();
		org.hibernate.query.Query query=session.createQuery("From BeveragesMenu");
		return query.list();
	} catch (Exception e) {
		e.printStackTrace();
		return null;
	} finally {
		if (session != null) {
			session.close();
		}
	}
	}
	}


