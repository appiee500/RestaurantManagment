package com.app.dao;

import java.util.List;
import com.app.model.OnlineBeverages;

public interface OnlineBeveragesDao {
	int addOnlineBeverages();
	List<OnlineBeverages> getMenu();
}
