package com.app.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.app.dao.FoodMenuDao;
import com.app.model.FoodMenu;
import com.app.model.OnlineFood;
import com.app.service.FoodMenuService;
import com.app.service.OnlineFoodService;
import com.app.util.HibernateUtil;

public class FoodMenuImpl implements FoodMenuDao {

	@Override
	public int addOfflineFood() {
		// TODO Auto-generated method stub
		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession();
			tx = session.beginTransaction();
		FoodMenu ofood= new FoodMenuService().addOfflineFood();
		session.save(ofood);
		tx.commit();

		return 1;
		
	}catch (Exception e) {
		e.printStackTrace();
		return 0;
	} finally {
		if (session != null) {
			session.close();
		}
	}
	}

	@Override
	public List<FoodMenu> getMenu() {
		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession();
			tx = session.beginTransaction();
		org.hibernate.query.Query query=session.createQuery("From FoodMenu");
		return query.list();
	} catch (Exception e) {
		e.printStackTrace();
		return null;
	} finally {
		if (session != null) {
			session.close();
		}
	}
	}
	
	}

