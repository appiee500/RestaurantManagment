package com.app.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.app.dao.OnlineBeveragesDao;
import com.app.model.OnlineBeverages;
import com.app.service.OnlineBeveragesService;
import com.app.util.HibernateUtil;

public class OnlineBeveragesImpl implements OnlineBeveragesDao {

	@Override
	public int addOnlineBeverages() {
		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession();
			tx = session.beginTransaction();
			OnlineBeverages obf= new OnlineBeveragesService().addOnlineBeverages();
		session.save(obf);
		tx.commit();

		return 1;
		
	}catch (Exception e) {
		e.printStackTrace();
		return 0;
	} finally {
		if (session != null) {
			session.close();
		}
	}
	}

	@Override
	public List<OnlineBeverages> getMenu() {
		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession();
			tx = session.beginTransaction();
		org.hibernate.query.Query query=session.createQuery("From OnlineBeverages");
		return query.list();
	} catch (Exception e) {
		e.printStackTrace();
		return null;
	} finally {
		if (session != null) {
			session.close();
		}
	}
	}
	}
