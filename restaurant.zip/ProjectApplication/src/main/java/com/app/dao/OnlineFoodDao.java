package com.app.dao;

import java.util.List;

import com.app.model.OnlineFood;

public interface OnlineFoodDao {

	int addOnlineFood();

	List<OnlineFood> getMenu();

}
