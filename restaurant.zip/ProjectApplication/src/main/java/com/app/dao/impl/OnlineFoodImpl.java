package com.app.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.app.dao.OnlineFoodDao;
import com.app.service.OnlineFoodService;
import com.app.util.HibernateUtil;
import com.mysql.cj.Query;
import com.app.model.OnlineFood;

public class OnlineFoodImpl implements OnlineFoodDao {

	@Override
	public int addOnlineFood() {
		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession();
			tx = session.beginTransaction();
		OnlineFood food= new OnlineFoodService().addFood();
		session.save(food);
		tx.commit();

		return 1;
	} catch (Exception e) {
		e.printStackTrace();
		return 0;
	} finally {
		if (session != null) {
			session.close();
		}
	}
	}

	@Override
	public List<OnlineFood> getMenu() {
		// TODO Auto-generated method stub
		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession();
			tx = session.beginTransaction();
		org.hibernate.query.Query query=session.createQuery("From OnlineFood");
		return query.list();
	} catch (Exception e) {
		e.printStackTrace();
		return null;
	} finally {
		if (session != null) {
			session.close();
		}
	}
	}
	
}

