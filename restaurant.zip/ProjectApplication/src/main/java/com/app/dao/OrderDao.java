package com.app.dao;

import java.util.List;
import java.util.Map;

import com.app.model.OrderMenu;

public interface OrderDao {
	int addOrder();
	List<OrderMenu> getMenu(List<Map<String, Integer>> orders, String user);
}
