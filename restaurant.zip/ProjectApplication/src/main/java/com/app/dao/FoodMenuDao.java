package com.app.dao;

import java.util.List;

import com.app.model.FoodMenu;

public interface FoodMenuDao {
	int addOfflineFood();
	List<FoodMenu> getMenu();

}
