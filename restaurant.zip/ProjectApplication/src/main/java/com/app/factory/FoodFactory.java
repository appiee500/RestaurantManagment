package com.app.factory;

import com.app.dao.BeveragesMenuDao;
import com.app.dao.FoodMenuDao;
import com.app.dao.OnlineBeveragesDao;
import com.app.dao.OnlineFoodDao;
import com.app.dao.OrderDao;
import com.app.dao.impl.BeveragesMenuImpl;
import com.app.dao.impl.FoodMenuImpl;
import com.app.dao.impl.OnlineBeveragesImpl;
import com.app.dao.impl.OnlineFoodImpl;
import com.app.dao.impl.OrderDaoImpl;

public class FoodFactory {
	public static OnlineFoodDao getOnlineFood() {
		return new OnlineFoodImpl();
	}
	
	public static FoodMenuDao getFoodMenu() {
		return new FoodMenuImpl();
	}
	public static OnlineBeveragesDao getOnlineBeverages() {
		return new OnlineBeveragesImpl();
	}

	public static BeveragesMenuDao getBeverages() {
		return new BeveragesMenuImpl();
	}

	public static OrderDao getOrder() {
		return new OrderDaoImpl();
	}
}
