package com.app.service;

import com.app.dto.InputRequest;
import com.app.model.BeveragesMenu;



public class BeveragesMenuService {
	public BeveragesMenu  addOfflineBeverages() {
		return InputRequest.addOfflineBeverages();
		
	}
}
