package com.app.service;

import com.app.dto.InputRequest;
import com.app.model.OnlineBeverages;

public class OnlineBeveragesService {
	public OnlineBeverages  addOnlineBeverages() {
		return InputRequest.addOnlineBeverages();
		
}
}
