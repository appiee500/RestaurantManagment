package com.app.service;

import com.app.dto.InputRequest;
import com.app.model.OrderMenu;

public class OrderMenuService {
	public OrderMenu  addOrder() {
		return InputRequest.addOrder();
		
	}
}
