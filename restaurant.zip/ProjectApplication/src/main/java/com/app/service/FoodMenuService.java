package com.app.service;

import com.app.dto.InputRequest;
import com.app.model.FoodMenu;

public class FoodMenuService {
	public FoodMenu  addOfflineFood() {
		return InputRequest.addOfflineFood();
		
	}
}
