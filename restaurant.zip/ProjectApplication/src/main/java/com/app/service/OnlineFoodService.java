package com.app.service;

import com.app.dto.InputRequest;
import com.app.model.OnlineFood;

public class OnlineFoodService {
	public OnlineFood  addFood() {
		return InputRequest.addOnlineFood();
		
	}
}
