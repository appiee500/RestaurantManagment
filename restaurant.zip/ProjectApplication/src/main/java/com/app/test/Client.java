package com.app.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.swing.plaf.basic.BasicBorders;

import com.app.dao.BeveragesMenuDao;
import com.app.dao.FoodMenuDao;
import com.app.dao.OnlineBeveragesDao;
import com.app.dao.OnlineFoodDao;
import com.app.dao.OrderDao;
import com.app.dao.USerDao;
import com.app.dao.impl.OrderDaoImpl;
import com.app.factory.FoodFactory;
import com.app.factory.UserFactory;
import com.app.model.CustomerOrder;
import com.app.model.User;
public class Client {

	public static void main(String[] args, Object CustomerOrder, Object Menu) {
		// TODO Auto-generated method stub
Scanner sn=new Scanner(System.in);
USerDao dao=UserFactory.getUser();
OnlineFoodDao food=FoodFactory.getOnlineFood();
FoodMenuDao ofood=FoodFactory.getFoodMenu();
OnlineBeveragesDao obf=FoodFactory.getOnlineBeverages();
BeveragesMenuDao obv= FoodFactory.getBeverages();
String custName="";

String ch="",fch="";
do {
	System.out.println("Welcome To The Restaurant");
	System.out.println("Press 1: Registeration");
	System.out.println("Press 2:  Login");
	System.out.println("Press 3:  Dine-in Menu");
	System.out.println("Press 4: Display Users");
	System.out.println("Press 5:  Display User on id");
	System.out.println("-------------------------------");
	System.out.println("Enter Your Choice:");
	int choice=sn.nextInt();
	switch (choice) {
	case 1:
		int i=dao.register();
		if(i==1) {
			System.out.println("Successfully Register");
			
		}else {
			System.out.println("Something went wrong...!");
		}
		break;
	case 2:
		User user=dao.login();
		if(user!=null &&user.getRole().equalsIgnoreCase("admin")) {
			System.out.println("welcome to admin portal.");
			do {
				System.out.println("press 1: add online food menu");
				System.out.println("press 2: add online beverages menu");
				System.out.println("press 3:add offline food menu");
				System.out.println("press 4:add offline beverages menu");
				System.out.println("Enter your choice:");
				int c=sn.nextInt();
				switch(c) {
				case 1:
					int fi=food.addOnlineFood();
					if(fi==1) {
						System.out.println("Successfully online food added");
						
					}else {
						System.out.println("Something went wrong...!");
					}
					break;
				case 2:
					int fb=obf.addOnlineBeverages();
					if(fb==1) {
						System.out.println("Successfully online beverages added");
						
					}else {
						System.out.println("Something went wrong...!");
					}
					break;	
				case 3:
					int fio=ofood.addOfflineFood();
					if(fio==1) {
						System.out.println("Successfully  offline food added");
						
					}else {
						System.out.println("Something went wrong...!");
					}
					break;
				case 4:
					int fio1=obv.addOfflineBeverages();
					if(fio1==1) {
						System.out.println("Successfully  offline Baverages added");
						
					}else {
						System.out.println("Something went wrong...!");
					}
					break;
				
					default:
						break;
				}
				System.out.println("Do you want to add more Item press(Y/y) ");
				fch=sn.next();
			}while(fch.equalsIgnoreCase("y"));
		}else if(user!=null &&user.getRole().equalsIgnoreCase("user")){
			custName=user.getUname();
			System.out.println("Welcome to User Portal..");
			System.out.println("---------------------!!------------------");
			do {
			System.out.println("Press 1 for online food menu");
			System.out.println("Press 2 for online beverages menu");
			int sw=sn.nextInt();
			switch(sw) {
			case 1:
				
				System.out.println("Online Food Menu:");
			System.out.println("Item Id\t Item Name \tPrice");
			List<com.app.model.OnlineFood>liFoods=food.getMenu();
			for(com.app.model.OnlineFood f:liFoods) {
				System.out.println(f.getOfId()+"\t"+f.getOfName()+"\t"+f.getOfPrice());
			}
			System.out.println("Enter the food name you want to order");
			
			
			break;
			case 2:
				OrderDaoImpl orderDaoImpl=new OrderDaoImpl();
				
				System.out.println("Online beverages Menu:");
			System.out.println("Item Id\t Item Name \tPrice");
			List<com.app.model.OnlineBeverages>liBFoods=obf.getMenu();
			for(com.app.model.OnlineBeverages f:liBFoods) {
				System.out.println(f.getObId()+"\t"+f.getObName()+"\t"+f.getObPrice());
			}
			//place order  
			String order=null;
			Map<String,Integer> orders=new HashMap<String,Integer>();
			List<Map<String,Integer>>listOrder=new ArrayList<Map<String,Integer>>();
			do {
				System.out.println("Enter your item Name:");
				String name =sn.next();
				System.out.println("Enter Your Quantity:");
				int qty=sn.nextInt();
				orders.put(name.toLowerCase(),qty);
				listOrder.add(orders);
				System.out.println("thank you...!you want more item please enter (o/O):");
			}while(order.equalsIgnoreCase("o"));
			List<CustomerOrder>customerOrders=new OrderDaoImpl().placeorder(listOrder,custName);
			System.out.println(customerOrders);
			break;
			default:
				System.out.println("Invalid input");
				break;
			}
			System.out.println("-----------------------------------------");
			System.out.println("Do you want to continue...(y)");
			ch=sn.next();
		}while(ch.equalsIgnoreCase("y"));
		}	else {
			System.out.println("Invallid username and password");
		}
		break;
	case 3:
		do {
			System.out.println("Press 1 for Dine-in food menu");
			System.out.println("Press 2 for Dine-in beverages menu");
			int sw=sn.nextInt();
			switch(sw) {
			case 1:
				System.out.println("Dine-in Food Menu:");
			System.out.println("Item Id\t Item Name \tPrice");
			List<com.app.model.FoodMenu>liFoods=ofood.getMenu();
			for(com.app.model.FoodMenu f:liFoods) {
				System.out.println(f.getFoodId()+"\t"+f.getFoodName()+"\t"+f.getFoodPrice());
			}
			break;
			case 2:
				System.out.println("Dine-in beverages Menu:");
			System.out.println("Item Id\t Item Name \tPrice");
			List<com.app.model.BeveragesMenu>liBFoods=obv.getMenu();
			for(com.app.model.BeveragesMenu f:liBFoods) {
				System.out.println(f.getbId()+"\t"+f.getbName()+"\t"+f.getbPrice());
			}
			break;
			default:
				System.out.println("Invalid input");
				break;
			}
			System.out.println("-----------------------------------------");
			System.out.println("Do you want to continue...(y)");
			ch=sn.next();
		}while(ch.equalsIgnoreCase("y"));
	case 4:
		List<User>list=dao.listOfUsers();
		list.stream().forEach(s->System.out.println(s.getId()+"\t"+s.getFisrtName()+" "+s.getLastName()+"\t"+s.getAddress()+"\t"+s.getMobile()));
	break;
	case 5:
		System.out.println("Enter your id for find user:");
		int id=sn.nextInt();
		User u1=dao.findById(id);
		System.out.println(u1);
		break;
	default:
		System.out.println("Invalid Request...!");
		break;
	}
	System.out.println("Do you want to continue...(y)");
	ch=sn.next();
}while(ch.equalsIgnoreCase("y"));
System.out.println("Thank you");
	}

	private static Map<String, Integer> custOrder(OrderDaoImpl orderDaoImpl) {
		// TODO Auto-generated method stub
		return null;
	}

}
